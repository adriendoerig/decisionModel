% run the model and spit out RT cumulative distribution and performance to
% compare with exptal data.

% close all
% drawnow

conds = cell(1,12);
% experimental design
for i = 1:12
    conds{i} = load(['cond', num2str(i)]);
end
stims = {
         [0.004, 0.016] %insert stim durations here, on vector per condition
         [0.01,  0.01]
         [0.016, 0.004]
         [0.008, 0.032]
         [0.02,  0.02]
         [0.032, 0.008]
         [0.016, 0.064]
         [0.04,  0.04]
         [0.064, 0.016]
         [0.032, 0.128]
         [0.08,  0.08]
         [0.128, 0.032]
         };
     
expRTs = {conds{1}.cond1{7},conds{2}.cond2{7},conds{3}.cond3{7},conds{4}.cond4{7},conds{5}.cond5{7},conds{6}.cond6{7},conds{7}.cond7{7},conds{8}.cond8{7},conds{9}.cond9{7},conds{10}.cond10{7},conds{11}.cond11{7},conds{12}.cond12{7}}; % insert expt RTs in ms here, one vector per condition
expPerfs = [35.95,52.9,71.78,29.19,50.67,67.21,20.28,42.42,73.38,23.13,47.97,74.01]./100; % insert expt perfs here (fraction of decision = 1), one number per condition
% expPerfs = [52.9, 50.67, 42.42, 47.97]./100;
nCond = length(stims);

modelRTs = cell(1,nCond); 
modelPerfs = zeros(1,nCond);
% p = [0.08 24.4003 24 0.15 0.02 0.3];
% pOpt = [0.0535 0.0536 0.0537];
Tstart = 0.08;
% p = [(atan(5*pOpt(1))*2/pi + 1)*0.2/2, (atan(pOpt(2))*2/pi + 1)*40/2, (atan(5*pOpt(3))*2/pi + 1)*40/2, Tstart, 0.02, 0.1];
p = [0.035   16.7   32 Tstart, 0.01, 0.5];
for iCond = 1:nCond
    iCond
    [modelRTs{iCond}, modelPerfs(iCond), ~] = decisionNeuralNew(stims{iCond},p);
end

% plot perfs
data = zeros(nCond,2);
data(:,1) = expPerfs;
data(:,2) = modelPerfs;
figure('Position',[5 539 512 439])
bar(data)
% % xt = get(gca, 'XTick');
% % set(gca, 'XTick', xt, 'XTickLabel', {'0.01 0.01' '0.02 0.02'})
legend('humans', 'model')
title('Performance for humans and model')
xlabel('condition')
ylabel('fraction of decisions in favour of first vernier')

% plot RT cumulative distributions
for iCond = 1:nCond
    figure('Position',[80+439*iCond/5 539 512 439])
    cdfplot(expRTs{iCond})
    hold on
    h = cdfplot(modelRTs{iCond});
    set(h,'color','r')
    title(['RT cumulative ditributions for condition ' num2str(iCond)])
    legend('humans', 'model')
    figure('Position',[80+439*iCond/5 539-512 512 439])
    ksdensity(modelRTs{iCond})
    hold on
    ksdensity(expRTs{iCond})
    legend('model', 'humans')
    title(['RT ditributions for condition ' num2str(iCond)])
end
