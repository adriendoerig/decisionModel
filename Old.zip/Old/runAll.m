% Run all conditions for all subjects and save model outputs + figures

clear

% set to 0 if you do not want to find the best Tstart 
% (e.g. if you already have the bestT values in the subject result folders)
findTstart = 0; 

[progPath,~,~] = fileparts(which(mfilename)); % get program directory
cd(progPath); % go there just in case we're not already


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% define shit, load shit & make experimental data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

nSubjects = 8;

stimCond = {
         [0.004, 0.016] %insert stim durations here, on vector per condition
         [0.01,  0.01]
         [0.016, 0.004]
         [0.008, 0.032]
         [0.02,  0.02]
         [0.032, 0.008]
         [0.016, 0.064]
         [0.04,  0.04]
         [0.064, 0.016]
         [0.032, 0.128]
         [0.08,  0.08]
         [0.128, 0.032]
         };
nCond = length(stimCond);

% make optimal parameter values (it is a cell containing one vector per
% subject). CAREFUL, these the values already treaded with the arctg
% nonlinearities used in the gradient descent, do not apply them again!
makepOpt;

% load experimental RTs
conds = cell(1,nCond);
for i = 1:12
    conds{i} = load(['cond', num2str(i)]);
end

% make cell arrays containing the experimental data (performances and RTs)
% for all subjects. 
% Each row of the cell is a subject.
expPerfs = {
    [28,39,65,16,30,65.5,17,21.5,57.5,10.5,38.5,55.5]./100
    [38.3,50.26,65.43,34.58,53.35,64.17,25.82,42.86,63.64,25.33,41.42,69.61]./100
    [22.17,47.5,75,23.5,44.25,72.25,18.3,43.86,70.5,20.6,37.34,74.12]./100
    [19.80,47.18,79.7,13.6,38.5,82.05,11.9,28.5,71.14,4.79,29.59,77.08]./100
    [22.08,45.98,74.56,16.5,39.44,68.43,15.19,26.45,67.59,12.85,19.75,57]./100
    [36.68,46.7,61.42,29.72,45.71,68.09,27.37,39.35,69.05,22.61,36.93,72.22]./100
    [35.95,52.9,71.78,29.19,50.67,67.21,20.28,42.42,73.38,23.13,47.97,74.01]./100
    [21.65,40.1,78.84,11.89,28.8,60.32,13.23,26.46,71.66,8.38,17.95,48.44]./100
    };
    % Each row of cells is a subject.
expRTs = {
    {conds{1}.cond1{1},conds{2}.cond2{1},conds{3}.cond3{1},conds{4}.cond4{1},conds{5}.cond5{1},conds{6}.cond6{1},conds{7}.cond7{1},conds{8}.cond8{1},conds{9}.cond9{1},conds{10}.cond10{1},conds{11}.cond11{1},conds{12}.cond12{1}};
    {conds{1}.cond1{2},conds{2}.cond2{2},conds{3}.cond3{2},conds{4}.cond4{2},conds{5}.cond5{2},conds{6}.cond6{2},conds{7}.cond7{2},conds{8}.cond8{2},conds{9}.cond9{2},conds{10}.cond10{2},conds{11}.cond11{2},conds{12}.cond12{2}};
    {conds{1}.cond1{3},conds{2}.cond2{3},conds{3}.cond3{3},conds{4}.cond4{3},conds{5}.cond5{3},conds{6}.cond6{3},conds{7}.cond7{3},conds{8}.cond8{3},conds{9}.cond9{3},conds{10}.cond10{3},conds{11}.cond11{3},conds{12}.cond12{3}};
    {conds{1}.cond1{4},conds{2}.cond2{4},conds{3}.cond3{4},conds{4}.cond4{4},conds{5}.cond5{4},conds{6}.cond6{4},conds{7}.cond7{4},conds{8}.cond8{4},conds{9}.cond9{4},conds{10}.cond10{4},conds{11}.cond11{4},conds{12}.cond12{4}};
    {conds{1}.cond1{5},conds{2}.cond2{5},conds{3}.cond3{5},conds{4}.cond4{5},conds{5}.cond5{5},conds{6}.cond6{5},conds{7}.cond7{5},conds{8}.cond8{5},conds{9}.cond9{5},conds{10}.cond10{5},conds{11}.cond11{5},conds{12}.cond12{5}};
    {conds{1}.cond1{6},conds{2}.cond2{6},conds{3}.cond3{6},conds{4}.cond4{6},conds{5}.cond5{6},conds{6}.cond6{6},conds{7}.cond7{6},conds{8}.cond8{6},conds{9}.cond9{6},conds{10}.cond10{6},conds{11}.cond11{6},conds{12}.cond12{6}};
    {conds{1}.cond1{7},conds{2}.cond2{7},conds{3}.cond3{7},conds{4}.cond4{7},conds{5}.cond5{7},conds{6}.cond6{7},conds{7}.cond7{7},conds{8}.cond8{7},conds{9}.cond9{7},conds{10}.cond10{7},conds{11}.cond11{7},conds{12}.cond12{7}};
    {conds{1}.cond1{8},conds{2}.cond2{8},conds{3}.cond3{8},conds{4}.cond4{8},conds{5}.cond5{8},conds{6}.cond6{8},conds{7}.cond7{8},conds{8}.cond8{8},conds{9}.cond9{8},conds{10}.cond10{8},conds{11}.cond11{8},conds{12}.cond12{8}}
    };
    
% we will put model outputs here
modelPerfs = cell(nSubjects,1);
modelRTs = cell(nSubjects,nCond);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% a big loop: find best Tstart and then run all conds for all subjects
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for s = 1:nSubjects
    close all
    s
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% make a folder for the subject if it doesn't exist yet
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    cd(progPath)
    % if there's no results directory for this subject we will create one
    if exist([progPath filesep '\results\subject' num2str(s)],'dir') == 0
        resDir = 0;
    else
        resDir = 1;
    end

    if resDir == 0
        if exist([progPath filesep '\results'],'dir') == 0
            mkdir('results');
        end
        cd([progPath, '\results'])
        mkdir(['subject' num2str(s)])
    end

    % define results path
    resPath = [progPath filesep '\results\subject' num2str(s)]; % path to data folder
    cd(progPath)
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % find best Tstart
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if findTstart
        KSstat = 0;
        bestErr = 1000000000;
        bestT = -1000;
        err = 0;
        step = 0.005;
        TstartModelRTs = cell(1,nCond); 
        TstartModelPerfs = zeros(1,nCond);

        for Tstart = 0.05:step:0.2
            KSstat = 0;   

            % model params
            p = [pOpt{s}(1), pOpt{s}(2), pOpt{s}(3), Tstart, pOpt{s}(4), pOpt{s}(5)];

            for iCond = 7:nCond     % the first conditions with low stim time are not affected by Tstart
                [TstartModelRTs{iCond}, TstartModelPerfs(iCond), ~] = decisionNeuralNew(stimCond{iCond}, p);
                [~,~,KSstatTemp] = kstest2(expRTs{s}{iCond},TstartModelRTs{iCond});
                KSstat = KSstat+KSstatTemp;
            end

            err = sum((TstartModelPerfs(7:end)-expPerfs{s}(7:end)).^2)*10 + KSstat;

            if err < bestErr
                bestT = Tstart;
                bestErr = err;
            end
        end

        cd(resPath)
        save('bestT','bestT')
        cd(progPath)
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % run all configurations for subject s with pOpt and best Tstart
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % first, get the bestT value
    cd(resPath)
    load 'bestT'
    cd(progPath)
    
    p = [pOpt{s}(1), pOpt{s}(2), pOpt{s}(3), bestT, pOpt{s}(4), pOpt{s}(5)];

    for iCond = 1:nCond
        [modelRTs{s}{iCond}, modelPerfs{s}(iCond), ~] = decisionNeuralNew(stimCond{iCond},p);
    end

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % plot and save results
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % plot perfs
    data = zeros(nCond,2);
    data(:,1) = expPerfs{s};
    data(:,2) = modelPerfs{s};
    figure('Position',[5 539 512 439])
    bar(data)
    % % xt = get(gca, 'XTick');
    % % set(gca, 'XTick', xt, 'XTickLabel', {'0.01 0.01' '0.02 0.02'})
    legend('humans', 'model')
    title('Performance for humans and model')
    xlabel('condition')
    ylabel('fraction of decisions in favour of first vernier')
    drawnow
    % save in appropriate folder
    cd(resPath);
    saveas(gcf,'performances.fig')
    saveas(gcf,'performances.bmp')
    cd(progPath);

    % plot RT cumulative distributions
    for iCond = 1:nCond
        figure('Position',[80+439*iCond/5 539 512 439])
        cdfplot(expRTs{s}{iCond})
        hold on
        h = cdfplot(modelRTs{s}{iCond});
        set(h,'color','r')
        title(['RT cumulative ditributions for condition ' num2str(iCond)])
        legend('humans', 'model')
        drawnow
        % save in appropriate folder
        cd(resPath);
        saveas(gcf,['RT cumulative ditributions for condition ' num2str(iCond) '.fig'])
        saveas(gcf,['RT cumulative ditributions for condition ' num2str(iCond) '.bmp'])
        cd(progPath);
        
        figure('Position',[80+439*iCond/5 539-512 512 439])
        ksdensity(modelRTs{s}{iCond})
        hold on
        ksdensity(expRTs{s}{iCond})
        legend('model', 'humans')
        title(['RT ditributions for condition ' num2str(iCond)])
        drawnow
        % save in appropriate folder
        cd(resPath);
        saveas(gcf,['RT ditributions for condition ' num2str(iCond) '.fig'])
        saveas(gcf,['RT ditributions for condition ' num2str(iCond) '.bmp'])
        cd(progPath);
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% plot and save results over all participants
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

cd(progPath)
% if there's no results directory for data over all participants, we will create one
if exist([progPath filesep '\results\globalResults'],'dir') == 0
    if exist([progPath filesep '\results'],'dir') == 0
        mkdir('results');
    end
    cd([progPath, '\results'])
    mkdir(['globalResults'])
end
% define results path
resPath = [progPath filesep '\results\globalResults']; % path to data folder
cd(progPath)

% compute mean performances and total RTs for each condition
meanExpPerfs = zeros(1,nCond);
meanModelPerfs = zeros(1,nCond);
for i = 1:nSubjects
    meanExpPerfs = meanExpPerfs + expPerfs{i}./nSubjects;
    meanModelPerfs = meanModelPerfs + modelPerfs{i}./nSubjects;
end

allExpRTs = cell(1,nCond);
allModelRTs = cell(1,nCond);
for i = 1:nCond
    for j = 1:nSubjects
        allExpRTs{i} = [allExpRTs{i}, expRTs{j}{i}];
        allModelRTs{i} = [allModelRTs{i}, modelRTs{j}{i}];
    end
end

% plot perfs
figure()
data = zeros(nCond,2);
data(:,1) = meanExpPerfs;
data(:,2) = meanModelPerfs;
bar(data)
legend('humans', 'model')
title('MEAN Performance for humans and model')
xlabel('condition')
ylabel('mean of fraction of decisions in favour of first vernier')
drawnow
% save in appropriate folder
cd(resPath);
saveas(gcf,'meanPerformances.fig')
saveas(gcf,'meanPerformances.bmp')
cd(progPath);

% plot RT cumulative distributions
for iCond = 1:nCond
    figure('Position',[80+439*iCond/5 539 512 439])
    cdfplot(allExpRTs{iCond})
    hold on
    h = cdfplot(allModelRTs{iCond});
    set(h,'color','r')
    title(['RT cumulative ditributions accross ALL SUBJECTS for condition ' num2str(iCond)])
    legend('humans', 'model')
    drawnow
    % save in appropriate folder
    cd(resPath);
    saveas(gcf,['RT cumulative ditributions accross ALL SUBJECTS for condition ' num2str(iCond) '.fig'])
    saveas(gcf,['RT cumulative ditributions accross ALL SUBJECTS for condition ' num2str(iCond) '.bmp'])
    cd(progPath);

    figure('Position',[80+439*iCond/5 539-512 512 439])
    ksdensity(allExpRTs{iCond})
    hold on
    ksdensity(allModelRTs{iCond})
    legend('model', 'humans')
    title(['RT ditributions accross ALL SUBJECTS for condition ' num2str(iCond)])
    drawnow
    % save in appropriate folder
    cd(resPath);
    saveas(gcf,['RT ditributions accross ALL SUBJECTS for condition ' num2str(iCond) '.fig'])
    saveas(gcf,['RT ditributions accross ALL SUBJECTS for condition ' num2str(iCond) '.bmp'])
    cd(progPath);
end

save('modelPerfs', 'modelPerfs')
save('modelRTs', 'modelRTs')
save('meanModelPerfs', 'meanModelPerfs')
save('meanExpPerfs', 'meanExpPerfs')
save('allModelRTs', 'allModelRTs')
save('allExpRTs', 'allExpRTs')