%get RTs from dv files of participants

participants = {'David','Elda','Francesco', 'Johannes', 'Pallavi', 'Prashant', 'Romain', 'Sara'};
conditions = 1:6;

% we will fill these with appropriate RTs
cond1 = cell(1,length(participants)); % 4-16
cond2 = cell(1,length(participants)); % 10-10
cond3 = cell(1,length(participants)); % 16-4
cond4 = cell(1,length(participants)); % 8-32
cond5 = cell(1,length(participants)); % 20-20
cond6 = cell(1,length(participants)); % 32-8
cond7 = cell(1,length(participants)); % 16-64
cond8 = cell(1,length(participants)); % 40-40
cond9 = cell(1,length(participants)); % 64-16
cond10 = cell(1,length(participants)); % 32-128
cond11 = cell(1,length(participants)); % 80-80
cond12 = cell(1,length(participants)); % 128-32

[progPath,~,~] = fileparts(which(mfilename)); % get program directory
cd(progPath); % go there just in case we're not already

for part = 1:length(participants)
    dataPath = [progPath, '\Data\', participants{part}];

    cd(dataPath);
    files = dir([dataPath, '\', '*.dv']);
    names = {files.name};
    for i = 1:length(names)
        current = readDvFile(names{i});
        for j = 1:length(current.trial_id)
            if strfind(names{i}, '1a')
                if current.context_no(j) == 1
                    cond1{part} = [cond1{part}, current.react_ti(j)];
                elseif current.context_no(j) == 2
                    cond5{part} = [cond5{part}, current.react_ti(j)];
                elseif current.context_no(j) == 3
                    cond6{part} = [cond6{part}, current.react_ti(j)];
                elseif current.context_no(j) == 4
                   cond7{part} = [cond7{part}, current.react_ti(j)];
                elseif current.context_no(j) == 5
                    cond11{part} = [cond11{part}, current.react_ti(j)];
                elseif current.context_no(j) == 6
                    cond12{part} = [cond12{part}, current.react_ti(j)];
                end
            elseif strfind(names{i}, '1b') 
                if current.context_no(j) == 1
                   cond2{part} = [cond2{part}, current.react_ti(j)];
                elseif current.context_no(j) == 2
                    cond3{part} = [cond3{part}, current.react_ti(j)];
                elseif current.context_no(j) == 3
                    cond4{part} = [cond4{part}, current.react_ti(j)];
                elseif current.context_no(j) == 4
                    cond8{part} = [cond8{part}, current.react_ti(j)];
                elseif current.context_no(j) == 5
                    cond9{part} = [cond9{part}, current.react_ti(j)];
                elseif current.context_no(j) == 6
                    cond10{part} = [cond10{part}, current.react_ti(j)];
                end
            elseif strfind(names{i}, '2a')
                if current.context_no(j) == 1
                    cond1{part} = [cond1{part}, current.react_ti(j)];
                elseif current.context_no(j) == 2
                    cond4{part} = [cond4{part}, current.react_ti(j)];
                elseif current.context_no(j) == 3
                    cond6{part} = [cond6{part}, current.react_ti(j)];
                elseif current.context_no(j) == 4
                    cond8{part} = [cond8{part}, current.react_ti(j)];
                elseif current.context_no(j) == 5
                    cond10{part} = [cond10{part}, current.react_ti(j)];
                elseif current.context_no(j) == 6
                    cond12{part} = [cond12{part}, current.react_ti(j)];
                end
            elseif strfind(names{i}, '2b')
                if current.context_no(j) == 1
                    cond2{part} = [cond2{part}, current.react_ti(j)];
                elseif current.context_no(j) == 2
                    cond3{part} = [cond3{part}, current.react_ti(j)];
                elseif current.context_no(j) == 3
                    cond5{part} = [cond5{part}, current.react_ti(j)];
                elseif current.context_no(j) == 4
                    cond7{part} = [cond7{part}, current.react_ti(j)];
                elseif current.context_no(j) == 5
                    cond9{part} = [cond9{part}, current.react_ti(j)];
                elseif current.context_no(j) == 6
                    cond11{part} = [cond11{part}, current.react_ti(j)];
                end
            else
                continue
            end
        end
    end

    cd(progPath);
end

for i = 1:12
    save(['cond', num2str(i)],['cond', num2str(i)])
end
