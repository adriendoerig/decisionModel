% p(1) = tau
% p(2) = c
% p(3) = sigmaV
% p(4) = widthTnd
% p(5) = meanTnd
% p(6) = mu0;

clear all

for iCond = 1:12
    conds{iCond} = load(['cond', num2str(iCond)]);
end
% empirical data (subject 7)
perfdata = [ 35.95,52.9,71.78,29.19,50.67,67.21,20.28,42.42,73.38,23.13,47.97,74.01]./100; 
expRTs = {conds{1}.cond1{7},conds{2}.cond2{7},conds{3}.cond3{7},conds{4}.cond4{7},conds{5}.cond5{7},conds{6}.cond6{7},conds{7}.cond7{7},conds{8}.cond8{7},conds{9}.cond9{7},conds{10}.cond10{7},conds{11}.cond11{7},conds{12}.cond12{7}};

% model outputs
nCond = 12;
modelRTs = cell(1,nCond); 
modelPerfs = zeros(1,nCond);
success = zeros(1,nCond);

pOpt = [0.0535 0.0536 0.0537];
conds = [0.004, 0.016 ;
         0.01,  0.01;
         0.016, 0.004;
         0.008, 0.032;
         0.02,  0.02;
         0.032, 0.008;
         0.016, 0.064;
         0.04,  0.04;
         0.064, 0.016;
         0.032, 0.128;
         0.08,  0.08;
         0.128, 0.032
        ];

KSstat = 0;
bestErr = 1000000000;
bestT = -1000;
err = 0;
step = 0.005;

for Tstart = 0.05:step:0.2
    KSstat = 0;
    Tstart
    
    % model params
    p = [(atan(5*pOpt(1))*2/pi + 1)*0.2/2, (atan(pOpt(2))*2/pi + 1)*40/2, (atan(5*pOpt(3))*2/pi + 1)*40/2, Tstart, 0.02, 0.1];

    for iCond = 7:nCond     % the first conditions with low stim time are not affected by Tstart
        [modelRTs{iCond}, modelPerfs(iCond), ~] = decisionNeuralNew(conds(iCond,:), p);
        [~,~,KSstatTemp] = kstest2(expRTs{iCond},modelRTs{iCond});
        KSstat = KSstat+KSstatTemp;
    end
    
    err = sum((modelPerfs(7:end)-perfdata(7:end)).^2)*10 + KSstat;

    if err < bestErr
        bestT = Tstart;
        bestErr = err;
    end
end

bestT
save('bestT', 'bestT');
