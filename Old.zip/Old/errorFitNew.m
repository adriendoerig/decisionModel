function [err] = errorFitNew(p)

    % Compute the error of the model prediction
    % Use with p0 = [...,...,...]; pOptimized = fminsearch(error,p0)

    % p(1) = tau
    % p(2) = c
    % p(3) = mu0;

    % load RTs (in case you don't have the saved RTs, make them with
    % getRTs).
    for i = 1:12
        conds{i} = load(['cond', num2str(i)]);
    end
    RTs = cell(1,12);
    % empirical data subject 1 VP01
%     RTdata = [408.50, 411.50, 439.75,411.50, 393.00,400.50,368.25,396.50,439.00];%,399.00,413.00,433.00
%     perfdata = [28,39,65,16,30,65.5,17,21.5,57.5]./100;%,10.5,38.5,55.5];%
%     expRTs = {conds{1}.cond1{1},conds{2}.cond2{1},conds{3}.cond3{1},conds{4}.cond4{1},conds{5}.cond5{1},conds{6}.cond6{1},conds{7}.cond7{1},conds{8}.cond8{1},conds{9}.cond9{1}};

    
     %empirical data subject 2 VP02
%      perfdata = [38.3,50.26,65.43,34.58,53.35,64.17,25.82,42.86,63.64]; %25.33,41.42,69.61
     
      %empirical data subject 3 VP03
%      perfdata = [22.17,47.5,75,23.5,44.25,72.25,18.3,43.86,70.5]; %,20.6,37.34,74.12
     
     %empirical data subject 4 VP04
%      perfdata = [ 19.80,47.18,79.7,13.6,38.5,82.05,11.9,28.5,71.14]; %,4.79,29.59,77.08

     %empirical data subject 5 VP05
%      perfdata = [ 22.08,45.98,74.56,16.5,39.44,68.43,15.19,26.45,67.59]; %,12.85,19.75,57
     
      %empirical data subject 6 VP06
%      perfdata = [ 36.68,46.7,61.42,29.72,45.71,68.09,27.37,39.35,69.05]; %,22.61,36.93,72.22
     
%            empirical data subject 7 VP07
%      perfdata = [ 35.95,52.9,71.78,29.19,50.67,67.21,20.28,42.42,73.38]./100; %,23.13,47.97,74.01
%      expRTs = {conds{1}.cond1{7},conds{2}.cond2{7},conds{3}.cond3{7},conds{4}.cond4{7},conds{5}.cond5{7},conds{6}.cond6{7},conds{7}.cond7{7},conds{8}.cond8{7},conds{9}.cond9{7}};
     
         %empirical data subject 8 VP08
     perfdata = [ 21.65, 40.1, 78.84, 11.89,28.8,60.32,13.23,26.46,71.66]./100; %,8.38,17.95,48.44
     expRTs = {conds{1}.cond1{8},conds{2}.cond2{8},conds{3}.cond3{8},conds{4}.cond4{8},conds{5}.cond5{8},conds{6}.cond6{8},conds{7}.cond7{8},conds{8}.cond8{8},conds{9}.cond9{8}}
    
     % model outputs
    KSstat = 0;
    cond = 9;
    modelRTs = cell(1,cond);
    perfs = zeros(1,cond);
    success = zeros(1,cond);
    conds = [0.004, 0.016 ;
             0.01,  0.01;
             0.016, 0.004;
             0.008, 0.032;
             0.02,  0.02;
             0.032, 0.008;
             0.016, 0.064;
             0.04,  0.04;
             0.064, 0.016;
%            0.032, 0.128;
%            0.08,  0.08;
%            0.128, 0.032
                ];
    
    for i = 1:cond
        [modelRTs{i}, perfs(i), success(i)] = decisionNeuralNew(conds(i,:), [(atan(5*p(1))*2/pi + 1)*0.2/2, (atan(p(2))*2/pi + 1)*40/2, (atan(5*p(3))*2/pi + 1)*40/2, 0.15, 0.02, 0.3]);
    end
    
    global nruns;
    nruns = nruns + 1
    
    p
    (cond-sum(success))
    for i = 1:cond
        [~,~,KSstatTemp] = kstest2(expRTs{i},modelRTs{i});
        KSstat = KSstat+KSstatTemp;
    end
    KSstat
    
    err = sum((perfs-perfdata).^2)*10 + 10^15*(cond-sum(success)) + KSstat


end
