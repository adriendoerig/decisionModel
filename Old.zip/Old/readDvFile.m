function data = readDvFile(filename, varargin)
% extracts the trial data from a DV file. If there are no data present,
% an error is printed and the program terminates.
% The function will return a structure whose elements are named after 
% the field names used in the dv file (only lowercase letters are used), 
% e.g. data.pool will contain the pool numbers (as a column vector by default).
% The function knows same optional flags that have to be listed following 
% the filename parameter, as there are:
%   'sort'      : sort data with respect to the LEVEL field
%   'invalid'   : take also invalid trials (if there is a valid field at all)
%   'merge'     : merge adjacent data lines that have the same LEVEL 
%   'return_row_vectors':   return the arrays in the data structure as row vectors
%
% If 'merge' is present, the merge operation takes place at the very end,
% particularly after a sort operation. When merging trials, the default operation 
% is to define the merged field value by the mean of the merged values. Only the
% fields 'trials' (which will be created if not present) and 'hits' are treated 
% differently, so they contain the sum of the merged values instead of the mean.
% The 'pool' field is removed, if trials with different pool values are
% merged.

    [fid message] = fopen(filename);
    if (fid==-1)
        error('Cannot open ''%s'' [%s].', filename, message);
    end
    headerIntro = 'POOL[0].DATA:';
    lhi = length(headerIntro);
    while (~feof(fid))
        line = fgetl(fid);
        if (length(line)>lhi & strcmp(line(1:lhi),headerIntro))%peut-etre mettre <=
            start = 1+length(headerIntro);
            %--- analyze header
            colCnt = 0;             % number of columns
            poolIdx = 0;
            levelIdx = 0;
            trialsIdx = 0;
            hitsIdx = 0;
            validIdx = 0;
            tiIdx = 0;
            while (1)
                %--- skip white spaces
                while (start < 1+length(line) & isspace(line(start)))
                    start = start+1;
                end
                if (start > length(line))
                    break
                end
                %--- read next string
                for (stop=start+1:length(line))
                    if (isspace(line(stop)))
                        break
                    end
                end
                if (stop>length(line))
                    stop = stop -1;
                end
                if (isspace(line(stop)))
                    stop = stop-1;
                end
                if (stop<=start)
                    break
                end
                %--- new field found
                colCnt = colCnt+1;
                dataFieldStr{colCnt} = lower(line(start:stop));
                switch (dataFieldStr{colCnt})
                    case 'pool'
                        poolIdx = colCnt;
                    case 'trials'
                        trialsIdx = colCnt;
                    case 'hits'
                        hitsIdx = colCnt;
                    case 'level'
                        levelIdx = colCnt;
                    case 'valid'
                        validIdx = colCnt;
                    case 'react_ti'
                        tiIdx = colCnt;
                    case 'pest_endval'
                        %--- PEST_ENDVAL is non-numeric and we just skip
                        %    it. Since it's the last field (hopefully),
                        %    we can do it in this simple way.
                        dataFieldStr(colCnt) = [];
                        colCnt = colCnt-1;
                        break           % leave the while loop here 
                end
                start = stop+1;
            end
            %--- read data lines
            %    data() will be an size(data lines, colCnt) array first, before we
            %    convert it to a structure, since it's easier to do the sorting etc. 
            %    with an array.
            dataCnt = 0;
            while (~feof(fid))
                line = fgetl(fid);
                A = sscanf(line,'%f ', colCnt)';
                if (length(A)~=colCnt)
                    break
                end
                dataCnt = dataCnt+1;
                data(dataCnt,:) = reshape(A',1,[]);
            end
            fclose(fid);
            %--- data shaping
            if (isempty(varargin))
                flags = {};
            else
                flags = cell2struct(varargin,varargin,2);
            end
            if (isfield(flags,'invalid'))
                flags = rmfield(flags,'invalid');
            else
                %--- remove trials that are marked to be invalid
                if (validIdx)
                    idx = squeeze(find(data(:,validIdx)~=0));
                    data = data(idx,:);
                end
            end
            if (isfield(flags,'sort'))
                flags = rmfield(flags,'sort');
                if (levelIdx)
                    data = sortrows(data, levelIdx);
                end
            end
            if (isfield(flags,'merge'))
                flags = rmfield(flags,'merge');
                if (trialsIdx==0)
                    %--- append a TRIALS field, because we need a counter
                    colCnt = colCnt + 1;
                    dataFieldStr{colCnt} = 'trials';
                    data(:,colCnt) = 1;
                    trialsIdx = colCnt;
                end
                i=1;
                while (i<=size(data,1))
                    clear idx;
                    idx(1) = i; 
                    for (j=i+1:size(data,1))
                        if (data(j,levelIdx)~=data(i,levelIdx))
                            break
                        end
                        idx(1+end) = j;
                    end
                    if (length(idx)>1)
                        if (poolIdx) 
                            if (length(find(data(idx,poolIdx)==data(i,poolIdx))) ~= length(idx))
                                %--- there are different pool numbers, so the
                                %    pool numbers will become inconsistent by merging them
                                poolIdx = 0;            % we cannot simply remove a column here, because we want to keep
                                                        % the other indices consistent, so we just set a flag
                           end
                        end
                        trials = sum(data(idx,trialsIdx));
                        if (hitsIdx)
                            hits = sum(data(idx,hitsIdx));
                        end
                        %--- default operation for all fields is to take the mean
                        data(i,:) = mean(data(idx,:));
                        %--- treat trials and hits field differently
                        data(i,trialsIdx) = trials;
                        if (hitsIdx)
                            data(i,hitsIdx) = hits;
                        end
                        %--- delete the data lines that have been merged to the current one 
                        data(idx(2:end),:) = [];
                    end
                    i = i+1;
                end
            end
            %--- finally build the structure to be returned
            if (isfield(flags,'return_row_vectors'))
                flags = rmfield(flags,'return_row_vectors');
                data = cell2struct(num2cell(data',2),dataFieldStr,1);
            else                
                %--- default is column vectors
                data = cell2struct(num2cell(data,1),dataFieldStr,2);
            end
            if (poolIdx==0 & isfield(data,'pool'))
                %--- pool numbers are invalid due to merge operation, so remove them 
                data = rmfield(data,'pool');
            end
            %--- check for unknown flags
            if (~isempty(flags))
                %--- abort with error message
                flags = fieldnames(flags);
                for (i=1:length(flags))
                    error('Unknown flag parameter ''%s''', flags{i});
                end
            end
            return
        end
    end
    fclose(fid);
    error(sprintf('Cannot read any data from the dv file ''%s''.',filename));
return

end