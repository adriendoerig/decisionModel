
close all
clear all
clc;

global nruns;
nruns = 0;
p0 = [0 0 0];
options = optimset('DiffMinChange', 0.1, 'DiffMaxChange', 10, 'MaxFunEvals', 1000);
pOptimized = fminsearchOS('errorFitNew', p0, options);

save('pOptimized','pOptimized');