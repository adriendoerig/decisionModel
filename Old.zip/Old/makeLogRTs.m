[progPath,~,~] = fileparts(which(mfilename)); % get program directory
cd(progPath);

% if there's no results directory for data over all participants, we will create one
if exist([progPath filesep '\results\globalResults'],'dir') == 0
    if exist([progPath filesep '\results'],'dir') == 0
        mkdir('results');
    end
    cd([progPath, '\results'])
    mkdir(['globalResults'])
end
% define results path
resPath = [progPath filesep '\results\globalResults']; % path to data folder
cd(progPath)
    
nSubjects = 8;

stimCond = {
         [0.004, 0.016] %insert stim durations here, on vector per condition
         [0.01,  0.01]
         [0.016, 0.004]
         [0.008, 0.032]
         [0.02,  0.02]
         [0.032, 0.008]
         [0.016, 0.064]
         [0.04,  0.04]
         [0.064, 0.016]
         [0.032, 0.128]
         [0.08,  0.08]
         [0.128, 0.032]
         };
nCond = length(stimCond);


for iCond = 1:nCond
    figure('Position',[80+439*iCond/5 539 512 439])
    cdfplot(allExpRTs{iCond})
    hold on
    h = cdfplot(allModelRTs{iCond});
    set(h,'color','r')
    title(['logRT cumulative ditributions accross ALL SUBJECTS for condition ' num2str(iCond)])
    legend('humans', 'model')
    set(gca,'xscale','log')
    drawnow
    % save in appropriate folder
    cd(resPath);
    saveas(gcf,['logRT cumulative ditributions accross ALL SUBJECTS for condition ' num2str(iCond) '.fig'])
    saveas(gcf,['logRT cumulative ditributions accross ALL SUBJECTS for condition ' num2str(iCond) '.bmp'])
    cd(progPath);
end
